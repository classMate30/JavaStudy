import java.io.IOException;

public class RandomCafe
{
	public static void main(String[] args) throws IOException
	{
		Cafe.open();
		Cafe.operate();
	}
}